/**
 * Theme: Dastone - Responsive Bootstrap 4 admin Dashboard
 * Author: Mannatthemes
 * Dragula Js
 */


var iconTochange;
dragula([document.getElementById("dragula-left"),
document.getElementById("dragula-right")]);
dragula([
    document.getElementById("project-list-left"),
    document.getElementById("project-list-center-left"),
    document.getElementById("project-list-center"),
    document.getElementById("project-list-center-right"),
    document.getElementById("project-list-right")
]);
